package com.vwg.shapechanger

import android.graphics.Paint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.widget.ImageView
import android.graphics.drawable.shapes.OvalShape
import android.graphics.drawable.ShapeDrawable




class MainActivity : AppCompatActivity() {

    lateinit var scolor:Spinner
    lateinit var sshape:Spinner
    lateinit var bdraw:Button
    lateinit var iv:ImageView
    private val paint = Paint()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        scolor=findViewById(R.id.color_spinner)
        sshape=findViewById(R.id.shape_spinner)
        iv=findViewById(R.id.img1)
        bdraw=findViewById(R.id.btnDraw)

        bdraw.setOnClickListener {
            val selcolor=scolor.selectedItem.toString()
            val selshape=sshape.selectedItem.toString()
            val bg = Bitmap.createBitmap(480, 800, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bg)

            paint.isAntiAlias = true
            if(selcolor.equals("RED")) {
               paint.setColor(Color.RED)
            } else if(selcolor.equals("GREEN")) {
                paint.setColor(Color.GREEN)
            } else if(selcolor.equals("BLUE")) {
                paint.setColor(Color.BLUE)
            }
            if(selshape.equals("RECT")) {

                canvas.drawRect(50f, 50f, 200f, 100f, paint)
                iv.setImageBitmap(bg)
            } else if(selshape.equals("SQUARE")) {
                canvas.drawRect(50f, 50f, 200f, 200f, paint)
                iv.setImageBitmap(bg)
            } else if(selshape.equals("CIRCLE")) {

                canvas.drawCircle(50f,50f,40f,paint)
                iv.setImageBitmap(bg)
            }

        }
    }
}
